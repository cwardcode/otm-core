from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ('schedule', '0006_update_text_fields_empty_string'),
        ('schedule', '0005_verbose_name_plural_for_calendar'),
    ]

    operations = [
    ]
